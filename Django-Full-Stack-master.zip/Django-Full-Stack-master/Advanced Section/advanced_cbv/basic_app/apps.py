from django.apps import AppConfig


class BsacicAppConfig(AppConfig):
    name = 'bsacic_app'
